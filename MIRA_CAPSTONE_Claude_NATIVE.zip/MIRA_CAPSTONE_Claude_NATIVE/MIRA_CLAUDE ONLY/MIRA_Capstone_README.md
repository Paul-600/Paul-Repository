# MIRA Capstone: AI-Powered Project Intelligence Assistant

Mira is a multi-agent project intelligence assistant for Nexora PMs/TPMs, built for the *Applied Agentic AI for PMs/TPMs* capstone using the ABCDE Ltd. AI Adoption Project. It is built in two forms inside one Claude Project:

1. **Agent chats**: one chat per agent, with the Orchestrator acting as the router.
2. **Published app**: `mira_app.html` as a Claude artifact, which routes automatically and includes a trace log and the T1-T12 evaluation runner.

The project structure is described in [`mira_capstone_project.json`](mira_capstone_project.json).

## Project chats

| # | Chat | Type | What it does | Baseline tests |
|---|---|---|---|---|
| 1 | MIRA - Orchestrator Agent | Router | Classifies the request; returns the route, reason and a cleaned-up request | All |
| 2 | MIRA - Planner Agent | Core | Structured project plan from the description and timeline | T1, T2, T9 |
| 3 | MIRA - Risk assessor Agent | Core | Categorized risk matrix or top-N risks, ranked by task-board evidence | T3, T4, T7 |
| 4 | MIRA - Status reporter Agent | Core | Weekly status report or count summary | T5, T6, T10 |
| 5 | MIRA - Milestone tracker Agent | Extended | Blocked, overdue and due-soon tasks; missed and at-risk milestones with actions | T8, T11 |
| 6 | MIRA - Stakeholder communications Agent | Extended | Audience-specific stakeholder update emails | T12 |
| 7 | MIRA - Project documentation review Agent | Review | Reviews the project documentation and capstone deliverables | - |
| 8 | MIRA - Publish mira_app.html artifact | Deployment | Publishes the app with automatic routing, trace log and evaluation | All |

## Architecture

```mermaid
flowchart LR
    PM[PM / TPM request] --> O[Orchestrator Agent]
    O -->|plan| P[Planner Agent]
    O -->|risk| R[Risk assessor Agent]
    O -->|status| S[Status reporter Agent]
    O -->|tracker| M[Milestone tracker Agent]
    O -->|stakeholder| C[Stakeholder communications Agent]
    O -->|vague / no data| Q[Clarification: ask for missing details]
    K[(Project knowledge:<br/>4 project files +<br/>mira_grounded_facts.json)] -.-> P & R & S & M & C
    P & R & S & M & C --> D[Project documentation review Agent]
    APP[mira_app.html artifact<br/>auto-routing, trace log, T1-T12 eval]
```

**Orchestration pattern:** Router. Each request goes to exactly one specialist agent, so no agent runs unnecessarily and every output stays focused.

**Grounding:** all agents treat `mira_grounded_facts.json` as the source of truth for counts, dates, statuses, risk ranks and RAG health, computed as of **2026-04-27**, with Week 1 starting **2026-03-30**. Agents must not invent tasks, milestones, risks, goals or figures.

## Project knowledge (upload to the Claude Project)

| File | Contents |
|---|---|
| `project_description.txt` | Scope, goals (15% fewer delivery delays, 10% lower operational costs), approach |
| `project_timeline.csv` | 8 phases over 24 weeks with activities and milestones |
| `project_risks.csv` | Risk register R01-R10 with impact and mitigation |
| `sample_task_board.csv` | 25 tasks with status, owner, sprint and due date |
| `mira_grounded_facts.json` | Pre-computed facts for the as-of date |

## How to use

1. Send your request to **MIRA - Orchestrator Agent**.
2. It replies with the route, the reason and a cleaned-up request.
3. Paste that request into the agent chat it names.
4. Vague requests, such as "We want to build a chatbot", get a clarification asking for scope, goals, timeline and team size instead of an invented plan.
5. Use **MIRA - Project documentation review Agent** to check outputs and write-ups before submission.
6. For automatic routing, traces and the evaluation, open the published **mira_app.html** artifact.

Shortcut: if you already know which agent you need, go straight to its chat.

## Baseline evaluation (T1-T12)

| ID | Request | Expected agent |
|---|---|---|
| T1 | Project plan for ABCDE Ltd | Planner |
| T2 | Project plan for "We want to build a chatbot." | Clarification |
| T3 | Risk assessment for ABCDE Ltd | Risk assessor |
| T4 | Risk assessment for "New project starting soon." | Clarification |
| T5 | Weekly status report, Sprint 3 | Status reporter |
| T6 | Weekly status report for "Things are going fine." | Clarification |
| T7 | Top 3 risks | Risk assessor |
| T8 | Blocked or at-risk tasks | Milestone tracker |
| T9 | Plan for a 2-week project, no details | Clarification |
| T10 | Count of done / in progress / to do | Status reporter |
| T11 | Milestones in the next 2 weeks | Milestone tracker |
| T12 | Stakeholder email for Sprint 2 | Stakeholder communications |

Run all 12 in the app's **Evaluation** tab and export the results as CSV for the submission.

## Notes

- **Data discrepancy:** the problem statement says the task board has 3 Done tasks; the CSV has 5 (T001-T005). Mira reports the data.
- **Snapshot data:** `mira_grounded_facts.json` is a snapshot. If the CSVs or the as-of date change, regenerate it and replace it in project knowledge.
- **Agent chats vs app:** in the chats, you do the routing by copying between chats, and there is no trace log. Use the app for evaluation evidence.
