# Expected Answers (Ground Truth) for the Baseline Tests

Computed from the provided files with `AS_OF_DATE = 2026-04-27` and `PROJECT_START = 2026-03-30` (Week 1 = 30 Mar 2026, which aligns Sprint 1 due dates with Phase 1). Re-run `node tests/test.js` if you change either date.

## Data note (worth mentioning in your write-up)
The problem statement says the board has "3 Done". The CSV actually has **5 Done** (T001–T005). Mira counts from the data, so the correct T10 answer is:

| Status | Count | Task IDs |
|---|---|---|
| Done | 5 | T001, T002, T003, T004, T005 |
| In Progress | 3 | T006, T007, T025 |
| Blocked | 1 | T024 |
| To Do | 16 | T008–T023 |
| Total | 25 | |

## Derived facts at 2026-04-27 (Week 5, Phase 3 Use Case Selection, current sprint = Sprint 3)

| Fact | Value |
|---|---|
| Blocked | T024 Security review of AI infrastructure (High, James Wong, due 2026-05-26, waiting for security team availability) |
| Overdue | T006 Identify data gaps and quality issues (due 2026-04-21, In Progress, Priya Nair) |
| Due within 7 days | T007 (04-28, In Progress), T025 (04-28, In Progress), T008 (05-02, To Do) |
| Missed milestone | Phase 2 Current State Analysis (due 2026-04-26): Current systems audit report, Gap analysis report, because T006 is open |
| Milestones in next 14 days | Phase 3 milestone "Final list of prioritized use cases with success criteria", due 2026-05-10 |
| At-risk future phase | Phase 4 Pilot Design, because T024 (Security review) is blocked |
| Overall health | **Amber** (score 3 = 1 blocked High task + 1 overdue task + 1 missed milestone) |
| Top 3 risks (evidence-based) | R09 Security Vulnerabilities (T024 blocked), R01 Data Quality (T006 overdue; T010, T011 due within 30 days), R05 Ethical & Legal (T025 legal review due 04-28) |
| Schedule observation | T017–T023 are due 1–5 weeks earlier than their timeline phases start (task board compressed vs timeline) |

## Per-test expectations

| ID | Correct behaviour |
|---|---|
| T1 | Plan with all 8 phases, weeks and dates, milestones per phase; objectives only "15% fewer delivery delays", "10% lower operational costs", "improved service responsiveness". Budget listed as not specified. |
| T2 | Clarification: asks for scope, goals, deliverables, timeline, team size. No phases. |
| T3 | All 10 register risks (R01–R10) in a matrix, ranked by live evidence, with logistics function mapping. No R11+. |
| T4 | Clarification: asks for project details. No risk IDs. |
| T5 | Sprint 3: T007 and T025 In Progress, T008 and T009 To Do, no Sprint 3 tasks done; carry-over T006 overdue; T024 blocked; health Amber. |
| T6 | "No task data available". No percentages, no statuses. |
| T7 | R09, R01, R05 with evidence task IDs. |
| T8 | T024 blocked; T006 overdue; T007, T025, T008 due within 7 days. |
| T9 | Clarification: notes the 2-week duration, asks scope, goals, deliverables, team. No plan. |
| T10 | Counts exactly as the table above. |
| T11 | Phase 3 milestone due 2026-05-10; notes Phase 2 milestones missed. No Phase 4+ milestones as "upcoming". |
| T12 | Email covering only T004, T005 (Done) and T006 (In Progress, overdue). No T007+ tasks. |
