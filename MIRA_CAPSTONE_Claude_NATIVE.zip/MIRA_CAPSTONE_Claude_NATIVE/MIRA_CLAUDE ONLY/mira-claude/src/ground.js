// ===== Grounding layer =====
function ground(files, cfg) {
// Deterministic layer: every count, date, status and ranking is computed HERE,
// so the LLM agents only narrate facts and can never invent them.

function parseCSV(text) {
  const rows = []; let row = []; let field = ''; let q = false;
  text = String(text).replace(/^\uFEFF/, '');
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"') { if (text[i + 1] === '"') { field += '"'; i++; } else q = false; }
      else field += c;
    } else if (c === '"') q = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && text[i + 1] === '\n') i++;
      row.push(field); field = '';
      if (row.some(v => v.trim() !== '')) rows.push(row);
      row = [];
    } else field += c;
  }
  if (field !== '' || row.length) { row.push(field); if (row.some(v => v.trim() !== '')) rows.push(row); }
  if (!rows.length) return [];
  const header = rows.shift().map(h => h.trim());
  return rows.map(r => Object.fromEntries(header.map((h, i) => [h, (r[i] ?? '').trim()])));
}

const DAY = 86400000;
const toDate = (s) => { const [y, m, d] = String(s).slice(0, 10).split('-').map(Number); return Date.UTC(y, m - 1, d); };
const fmt = (t) => new Date(t).toISOString().slice(0, 10);

const asOfStr = cfg.as_of_override || cfg.AS_OF_DATE;
const asOf = toDate(asOfStr);
const start = toDate(cfg.PROJECT_START);
const WINDOW = Number(cfg.MILESTONE_WINDOW_DAYS || 14);

const description = String(files.description || '').trim();
const timelineRaw = parseCSV(files.timeline);
const risksRaw = parseCSV(files.risks);
const tasksRaw = parseCSV(files.tasks);

// ---------- Tasks ----------
const counts = { 'Done': 0, 'In Progress': 0, 'Blocked': 0, 'To Do': 0 };
const tasks = tasksRaw.map(t => {
  const due = toDate(t.due_date);
  const days = Math.round((due - asOf) / DAY);
  const open = t.status !== 'Done';
  counts[t.status] = (counts[t.status] || 0) + 1;
  return {
    task_id: t.task_id, task_name: t.task_name, status: t.status, assignee: t.assignee,
    priority: t.priority, sprint: t.sprint, sprint_num: parseInt(String(t.sprint).replace(/\D/g, ''), 10),
    due_date: t.due_date, labels: t.labels, description: t.description,
    due_in_days: days, is_overdue: open && days < 0, due_within_7d: open && days >= 0 && days <= 7,
  };
});
counts.Total = tasks.length;

// ---------- Timeline (week numbers -> calendar dates) ----------
const timeline = timelineRaw.map(p => {
  const sw = Number(p.start_week), ew = Number(p.end_week);
  const sd = start + (sw - 1) * 7 * DAY, ed = start + ew * 7 * DAY - DAY;
  return {
    phase: Number(p.phase), phase_name: p.phase_name, start_week: sw, end_week: ew,
    start_date: fmt(sd), end_date: fmt(ed), _sd: sd, _ed: ed,
    key_activities: p.key_activities.split(';').map(s => s.trim()).filter(Boolean),
    milestones: p.milestones_deliverables.split(';').map(s => s.trim()).filter(Boolean),
  };
});

// Link tasks to phases by label; cross-cutting labels (Security, Compliance) by due date.
const LABEL_PHASE = { 'Planning': 1, 'Analysis': 2, 'Use Cases': 3, 'Data Prep': 4, 'Model Dev': 4, 'Pilot': 5, 'Evaluation': 6, 'Deployment': 7, 'Monitoring': 8 };
const phaseForDate = (d) => {
  const p = timeline.find(x => d >= x._sd && d <= x._ed);
  if (p) return p.phase;
  return d < timeline[0]._sd ? timeline[0].phase : timeline[timeline.length - 1].phase;
};
tasks.forEach(t => { t.phase = LABEL_PHASE[t.labels] ?? phaseForDate(toDate(t.due_date)); });

const schedule_observations = [];
timeline.forEach(p => {
  const linked = tasks.filter(t => t.phase === p.phase);
  const open = linked.filter(t => t.status !== 'Done');
  const issues = [];
  open.filter(t => t.status === 'Blocked').forEach(t => issues.push(`${t.task_id} (${t.task_name}) is Blocked`));
  open.filter(t => t.is_overdue).forEach(t => issues.push(`${t.task_id} (${t.task_name}) is overdue: due ${t.due_date}, status ${t.status}`));
  open.filter(t => toDate(t.due_date) > p._ed).forEach(t => issues.push(`${t.task_id} due ${t.due_date} is after the phase end date ${p.end_date}`));
  linked.filter(t => toDate(t.due_date) < p._sd).forEach(t =>
    schedule_observations.push(`${t.task_id} (${t.task_name}, label ${t.labels}) is due ${t.due_date}, before Phase ${p.phase} (${p.phase_name}) starts on ${p.start_date}`));
  let status;
  if (asOf > p._ed) status = open.length ? 'Ended - milestones not achieved' : 'Completed';
  else if (asOf >= p._sd) status = 'In progress';
  else status = 'Not started';
  p.phase_status = status;
  p.milestone_risk = status === 'Completed' ? 'Achieved' : (issues.length ? (status.startsWith('Ended') ? 'Missed' : 'At risk') : 'On track');
  p.milestone_issues = issues;
  p.days_until_phase_end = Math.round((p._ed - asOf) / DAY);
  p.linked_tasks = linked.map(t => `${t.task_id} ${t.task_name} [${t.status}, due ${t.due_date}]`);
});

const current_week = Math.floor((asOf - start) / DAY / 7) + 1;
const curPhase = timeline.find(p => asOf >= p._sd && asOf <= p._ed) || null;
const futureSprints = tasks.filter(t => toDate(t.due_date) >= asOf).map(t => t.sprint_num);
const current_sprint = futureSprints.length ? Math.min(...futureSprints) : null;

const strip = (p) => { const { _sd, _ed, ...rest } = p; return rest; };
const upcoming_milestones = timeline.filter(p => p._ed >= asOf && p._ed <= asOf + WINDOW * DAY).map(p => ({
  phase: p.phase, phase_name: p.phase_name, due_date: p.end_date, days_away: p.days_until_phase_end,
  milestones: p.milestones, milestone_risk: p.milestone_risk, issues: p.milestone_issues,
}));
const missed_milestones = timeline.filter(p => p.milestone_risk === 'Missed').map(p => ({
  phase: p.phase, phase_name: p.phase_name, was_due: p.end_date, milestones: p.milestones, issues: p.milestone_issues,
}));

const brief = (t) => ({ task_id: t.task_id, task_name: t.task_name, status: t.status, assignee: t.assignee, priority: t.priority, sprint: t.sprint, due_date: t.due_date, due_in_days: t.due_in_days, description: t.description });
const blocked = tasks.filter(t => t.status === 'Blocked').map(brief);
const overdue = tasks.filter(t => t.is_overdue).map(brief);
const due_within_7d = tasks.filter(t => t.due_within_7d).map(brief);

// ---------- Risks: rank by live evidence from the task board ----------
const RISK_EVIDENCE_RULES = {
  R01: /data gap|data quality|cleaning|historical demand/i,
  R02: /ERP|integrat|pipeline|deploy/i,
  R03: /vendor|skill|hire|expertise/i,
  R04: /staff|adopt|pilot with|survey users/i,
  R05: /legal|privacy|compliance/i,
  R06: /vendor|ML platform|budget/i,
  R07: /success criteria|KPI|stakeholder|leadership/i,
  R08: /drift|monitoring|retrain/i,
  R09: /security|penetration|vulnerab/i,
  R10: /vendor|platform|open standard/i,
};
const signal = (t) => {
  if (t.status === 'Done') return 0;
  let s = t.status === 'Blocked' ? 3 : (t.is_overdue ? 2 : 0);
  if (!t.is_overdue) {
    if (t.due_within_7d) s += t.status === 'In Progress' ? 1.5 : 1;
    else if (t.due_in_days <= 30) s += 0.5;
  }
  return s;
};
const risks = risksRaw.map(r => {
  const rule = RISK_EVIDENCE_RULES[r.risk_id];
  const related = rule ? tasks.filter(t => rule.test(`${t.task_name} ${t.description}`) && t.status !== 'Done') : [];
  const evidence = related.map(t => ({ task_id: t.task_id, task_name: t.task_name, status: t.status, due_date: t.due_date, signal: signal(t) })).filter(e => e.signal > 0);
  const score = Math.round(evidence.reduce((a, e) => a + e.signal, 0) * 10) / 10;
  return { ...r, evidence_score: score, evidence_priority: score >= 3 ? 'High' : score >= 1 ? 'Medium' : 'Low (monitor)', evidence };
}).sort((a, b) => b.evidence_score - a.evidence_score || a.risk_id.localeCompare(b.risk_id));
risks.forEach((r, i) => { r.rank = i + 1; });

// ---------- Overall health (transparent rule) ----------
const blockedHigh = tasks.filter(t => t.status === 'Blocked' && t.priority === 'High');
const healthScore = blockedHigh.length + overdue.length + missed_milestones.length;
const health = {
  rag: healthScore >= 4 ? 'Red' : healthScore >= 1 ? 'Amber' : 'Green',
  rule: 'score = high-priority blocked tasks + overdue tasks + missed milestones; 0 = Green, 1-3 = Amber, 4+ = Red',
  score: healthScore,
  reasons: [
    ...blockedHigh.map(t => `${t.task_id} ${t.task_name} is Blocked (High priority)`),
    ...overdue.map(t => `${t.task_id} ${t.task_name} is overdue (due ${t.due_date}, ${t.status})`),
    ...missed_milestones.map(m => `Phase ${m.phase} ${m.phase_name} milestones were due ${m.was_due} and are not achieved`),
  ],
};

const team = {};
tasks.forEach(t => {
  team[t.assignee] = team[t.assignee] || { assignee: t.assignee, total: 0, open: 0, labels: new Set() };
  team[t.assignee].total++; if (t.status !== 'Done') team[t.assignee].open++; team[t.assignee].labels.add(t.labels);
});
const team_from_task_board = Object.values(team).map(m => ({ ...m, labels: [...m.labels] }));

return ({
    as_of_date: fmt(asOf), project_start: fmt(start), current_week, current_sprint,
    current_phase: curPhase ? { phase: curPhase.phase, phase_name: curPhase.phase_name, start_date: curPhase.start_date, end_date: curPhase.end_date } : null,
    milestone_window_days: WINDOW,
    project_description: description,
    timeline: timeline.map(strip),
    task_counts: counts,
    tasks,
    blocked, overdue, due_within_7d,
    upcoming_milestones, missed_milestones,
    risks, health, team_from_task_board, schedule_observations,
    source_files: ['project_description.txt', 'project_timeline.csv', 'project_risks.csv', 'sample_task_board.csv'],
});

}
