(function () {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const SEED = JSON.parse($('#seed').textContent);
  const store = {
    get(k, d) { try { const v = localStorage.getItem('mira.' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('mira.' + k, JSON.stringify(v)); } catch (e) { /* storage unavailable or full */ } },
    del(k) { try { localStorage.removeItem('mira.' + k); } catch (e) { } },
  };
  const DEFAULT_SETTINGS = { AS_OF_DATE: '2026-04-27', PROJECT_START: '2026-03-30', MILESTONE_WINDOW_DAYS: 14, tier: 'default', price_in: 3, price_out: 15 };
  const S = {
    files: Object.assign({}, SEED.files, store.get('files', {})),
    settings: Object.assign({}, DEFAULT_SETTINGS, store.get('settings', {})),
    traces: store.get('traces', []),
    evalResults: store.get('eval', {}),
    selected: null, sample: null, downloads: null, busy: false, ctl: null, evalStop: false,
  };
  let facts = null;
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const md = (t) => {
    const src = String(t || '').replace(/^```(?:markdown|md)?\s*\n([\s\S]*?)\n```\s*$/, '$1');
    if (window.marked && window.DOMPurify) return DOMPurify.sanitize(marked.parse(src, { gfm: true, breaks: false }));
    return '<pre>' + esc(src) + '</pre>';
  };
  const cfg = () => ({ AS_OF_DATE: S.settings.AS_OF_DATE, PROJECT_START: S.settings.PROJECT_START, MILESTONE_WINDOW_DAYS: S.settings.MILESTONE_WINDOW_DAYS });
  const costOf = (tr) => ((tr.in_tokens || 0) * S.settings.price_in + (tr.out_tokens || 0) * S.settings.price_out) / 1e6;
  const fmtCost = (c) => '$' + (c < 0.01 ? c.toFixed(4) : c.toFixed(3));
  const fmtMs = (ms) => ms >= 1000 ? (ms / 1000).toFixed(1) + ' s' : Math.round(ms) + ' ms';
  const toast = (msg) => { const t = $('#toast'); t.textContent = msg; t.hidden = false; clearTimeout(toast._t); toast._t = setTimeout(() => { t.hidden = true; }, 2600); };
  const errCopy = (code) => ({
    not_granted: 'Claude access was declined for this page, so agents can’t run. Reload the page to be asked again.',
    rate_limited: 'Too many requests at once. Wait a moment, then send again.',
    usage_limit: 'Your Claude usage limit has been reached for now.',
    cancelled: 'Stopped.',
  }[code] || `The request failed (${code || 'unknown error'}). Try again.`);

  // ---------- grounding + header ----------
  function regrounding() {
    try { facts = ground(S.files, cfg()); }
    catch (e) { facts = null; toast('Couldn’t read the project files. Check the Data tab.'); }
    renderHeader(); renderFacts(); renderFiles();
  }
  function renderHeader() {
    const f = facts; if (!f) return;
    const rag = f.health.rag, rc = rag === 'Green' ? 'g' : rag === 'Amber' ? 'a' : 'r';
    $('#asof').innerHTML = `<span>As of ${esc(f.as_of_date)}, week ${f.current_week}${f.current_sprint ? `, Sprint ${f.current_sprint}` : ''}</span><span class="pill ${rc}">Health ${esc(rag)}</span>`;
    const tl = f.timeline, n = tl.length, pad = 7;
    const pos = (i) => pad + i * (100 - pad * 2) / (n - 1);
    const curIdx = Math.max(0, tl.findIndex(p => f.current_phase && p.phase === f.current_phase.phase));
    let h = `<div class="route-line"></div><div class="route-done" style="width:${pos(curIdx)}%"></div>`;
    tl.forEach((p, i) => {
      const cls = p.milestone_risk === 'Achieved' ? 'ok' : p.milestone_risk === 'Missed' ? 'missed' : p.milestone_risk === 'At risk' ? 'atrisk' : '';
      const isNow = i === curIdx && f.current_phase;
      const st = p.milestone_risk === 'On track' ? (p.phase_status === 'Not started' ? 'Not started' : 'On track') : p.milestone_risk;
      h += `<div class="stop ${cls}${isNow ? ' now' : ''}" style="left:${pos(i)}%" title="Milestones: ${esc(p.milestones.join('; '))} (due ${esc(p.end_date)})"><div class="wk">${isNow ? `<b style="color:var(--route)">Now, wk ${f.current_week}</b>` : `Wk ${p.start_week}–${p.end_week}`}</div><div class="dot"></div><div class="nm">${esc(p.phase_name)}</div><div class="st">${esc(st)} · ${esc(p.end_date.slice(5))}</div></div>`;
    });
    $('#track').innerHTML = h;
    const c = f.task_counts;
    $('#strip').innerHTML = `<span class="pill g">${c['Done']} done</span><span class="pill t">${c['In Progress']} in progress</span><span class="pill r">${c['Blocked']} blocked</span><span class="pill">${c['To Do']} to do</span>` +
      (f.overdue.length ? `<span class="pill a">${f.overdue.length} overdue: ${esc(f.overdue.map(t => t.task_id).join(', '))}</span>` : '') +
      (f.upcoming_milestones.length ? `<span class="pill">Next milestone ${esc(f.upcoming_milestones[0].due_date)}</span>` : '');
  }

  // ---------- tabs ----------
  const TABS = ['chat', 'traces', 'evaluation', 'data'];
  function showTab() {
    const t = TABS.includes(location.hash.slice(1)) ? location.hash.slice(1) : 'chat';
    TABS.forEach(n => { $('#v-' + n).classList.toggle('on', n === t); });
    $$('nav.tabs a').forEach(a => { if (a.dataset.tab === t) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
  }
  window.addEventListener('hashchange', showTab);

  // ---------- traces ----------
  function saveTraces() { S.traces = S.traces.slice(0, 200); store.set('traces', S.traces.map(t => ({ ...t, prompt: t.prompt ? t.prompt.slice(0, 20000) : t.prompt }))); }
  function addTrace(tr) { const i = S.traces.findIndex(x => x.id === tr.id); if (i >= 0) S.traces[i] = tr; else S.traces.unshift(tr); saveTraces(); renderTraceList(); }
  function renderTraceList() {
    $('#tcount').textContent = S.traces.length ? S.traces.length : '';
    const done = S.traces.filter(t => t.status === 'ok');
    if (S.traces.length) {
      const avg = done.length ? done.reduce((a, t) => a + t.total_ms, 0) / done.length : 0;
      const tok = S.traces.reduce((a, t) => a + (t.in_tokens || 0) + (t.out_tokens || 0), 0);
      const cost = S.traces.reduce((a, t) => a + costOf(t), 0);
      $('#tsum').textContent = `${S.traces.length} traces, avg ${fmtMs(avg)}, ~${tok.toLocaleString()} tokens, est. ${fmtCost(cost)}`;
    } else $('#tsum').textContent = 'No traces yet';
    $('#tlist').innerHTML = S.traces.map(t => `<button class="trow" role="option" aria-selected="${t.id === S.selected}" data-id="${t.id}"><span class="q">${esc(t.request)}</span><span class="m">${esc(t.agent || '…')} · ${t.status === 'running' ? 'running' : fmtMs(t.total_ms || 0)} · ${esc(t.source)} · ${new Date(t.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span></button>`).join('')
      || '<div class="empty">Nothing recorded yet.</div>';
  }
  function renderTraceDetail() {
    const t = S.traces.find(x => x.id === S.selected);
    if (!t) return;
    const total = Math.max(t.total_ms || 1, ...t.steps.map(s => s.started + s.ms), 1);
    const wf = t.steps.map(s => `<div class="wfrow"><div>${esc(s.name)}<span class="kind">${s.kind === 'llm' ? 'Claude' : s.kind === 'rule' ? 'rules' : 'code'}</span></div>
      <div class="bar"><i class="${s.status === 'error' ? 'error' : s.kind}" style="left:${(s.started / total) * 100}%;width:${Math.max((s.ms / total) * 100, 0.8)}%"></i></div><div style="text-align:right">${fmtMs(s.ms)}</div>
      <div class="d">${esc(s.detail || '')}${s.in_tokens || s.out_tokens ? ` · ~${s.in_tokens} in / ~${s.out_tokens} out tokens` : ''}${s.error ? ` · error: ${esc(s.error)}` : ''}</div></div>`).join('');
    $('#tdetail').innerHTML = `<div class="panel">
      <h2>${esc(t.request)}</h2>
      <div class="note" style="margin-top:0">${esc(new Date(t.at).toLocaleString())} · ${esc(t.source)} · trace ${esc(t.id)}${t.model ? ' · ' + esc(t.model) : ''}</div>
      <div class="kv"><div><small>Route</small><span>${esc(t.route || '–')}</span></div><div><small>Agent</small><span>${esc(t.agent || '–')}</span></div>
      <div><small>Latency</small><span>${fmtMs(t.total_ms || 0)}</span></div><div><small>Claude calls</small><span>${t.llm_calls ?? 0}</span></div>
      <div><small>Est. tokens</small><span>${((t.in_tokens || 0) + (t.out_tokens || 0)).toLocaleString()}</span></div><div><small>Est. API cost</small><span>${fmtCost(costOf(t))}</span></div></div>
      <div class="wf">${wf}</div>
      ${t.error ? `<p class="fails">Error: ${esc(errCopy(t.error))}</p>` : ''}
      <details><summary>Guardrail decision</summary><pre>${esc(JSON.stringify(t.decision || {}, null, 2))}</pre></details>
      <details><summary>Orchestrator output</summary><pre>${esc(JSON.stringify((t.steps.find(s => s.name === 'Orchestrator agent') || {}).output || {}, null, 2))}</pre></details>
      ${t.prompt ? `<details><summary>Agent prompt (instructions + grounded context)</summary><pre>${esc(t.prompt)}</pre></details>` : ''}
      <details open><summary>Output</summary><div class="md">${md(t.output)}</div></details></div>`;
  }
  $('#tlist').addEventListener('click', (e) => { const b = e.target.closest('.trow'); if (!b) return; S.selected = b.dataset.id; renderTraceList(); renderTraceDetail(); });
  $('#tclear').addEventListener('click', () => { if (!S.traces.length) return; S.traces = []; S.selected = null; saveTraces(); renderTraceList(); $('#tdetail').innerHTML = '<div class="empty"><strong>Log cleared</strong>New requests will appear here.</div>'; toast('Trace log cleared'); });
  function openTrace(id) { S.selected = id; location.hash = 'traces'; renderTraceList(); renderTraceDetail(); }

  // ---------- chat ----------
  const CHIPS = [['T5', 'Weekly status, Sprint 3'], ['T8', 'Blocked and at-risk tasks'], ['T7', 'Top 3 risks'], ['T11', 'Milestones, next 2 weeks'], ['T12', 'Stakeholder email, Sprint 2'], ['T1', 'Full project plan'], ['T2', 'Vague request (guardrail test)']];
  $('#chips').innerHTML = CHIPS.map(([id, label]) => `<button class="chip" data-id="${id}"><small>${id}</small>${esc(label)}</button>`).join('');
  $('#chips').addEventListener('click', (e) => { const b = e.target.closest('.chip'); if (!b) return; const c = EVAL_CASES.find(x => x.id === b.dataset.id); $('#box').value = c.request; send(); });
  const box = $('#box');
  box.addEventListener('input', () => { box.style.height = 'auto'; box.style.height = Math.min(box.scrollHeight, 180) + 'px'; });
  box.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
  $('#send').addEventListener('click', send);
  $('#stop').addEventListener('click', () => S.ctl && S.ctl.abort());

  function stepDots(tr) { return `<span class="steps" aria-hidden="true">${tr.steps.map(s => `<i class="${s.status}"></i>`).join('')}</span>`; }
  async function send() {
    const q = box.value.trim();
    if (!q || S.busy) return;
    if (!S.sample) { toast('Claude isn’t available in this view.'); return; }
    if (!facts) { toast('Load the project files first.'); return; }
    S.busy = true; $('#send').disabled = true; $('#stop').hidden = false; box.value = ''; box.style.height = 'auto';
    $('#chatempty') && $('#chatempty').remove();
    const msgs = $('#msgs');
    msgs.insertAdjacentHTML('beforeend', `<div class="msg user">${esc(q)}</div>`);
    const bot = document.createElement('div'); bot.className = 'msg bot';
    bot.innerHTML = `<div class="meta"><b>Orchestrator</b><span class="info">reading your request</span><span class="dots"></span><button class="linkbtn" hidden>Open trace</button></div><div class="thinking">Thinking…</div>`;
    msgs.appendChild(bot); bot.scrollIntoView({ block: 'nearest' });
    S.ctl = new AbortController();
    let raf = 0, latest = '';
    const body = () => bot.querySelector('.thinking, .md');
    const tr = await runMira(q, {
      sample: S.sample, files: S.files, cfg: cfg(), tier: S.settings.tier, signal: S.ctl.signal, source: 'chat',
      onStep: (t) => {
        bot.querySelector('.dots').innerHTML = stepDots(t);
        const cur = t.steps[t.steps.length - 1];
        bot.querySelector('b').textContent = t.agent ? t.agent : 'Orchestrator';
        bot.querySelector('.info').textContent = t.status === 'running' ? (cur ? cur.name.toLowerCase() + '…' : '') : `${t.route} · ${fmtMs(t.total_ms || 0)}`;
        addTrace(t);
      },
      onText: (text) => {
        latest = text; if (raf) return;
        raf = requestAnimationFrame(() => { raf = 0; const el = body(); if (el.classList.contains('thinking')) { el.className = 'md'; } el.innerHTML = md(latest); });
      },
    });
    if (raf) cancelAnimationFrame(raf);
    const el = body();
    if (tr.output) { el.className = 'md'; el.innerHTML = md(tr.output); }
    if (tr.status !== 'ok') { el.insertAdjacentHTML('beforeend', `<p class="fails" style="padding:0 18px 12px">${esc(errCopy(tr.error))}</p>`); if (el.classList.contains('thinking')) el.textContent = ''; }
    const lb = bot.querySelector('.linkbtn'); lb.hidden = false; lb.onclick = () => openTrace(tr.id);
    addTrace(tr);
    S.busy = false; $('#send').disabled = false; $('#stop').hidden = true; S.ctl = null; box.focus();
  }

  // ---------- evaluation ----------
  function renderEval() {
    const rows = EVAL_CASES.map(c => {
      const r = S.evalResults[c.id];
      const res = !r ? '<span class="res">–</span>' : r.running ? '<span class="res run">Running</span>' : r.error ? `<span class="res fail">Error</span>` : `<span class="res ${r.pass ? 'pass' : 'fail'}">${r.pass ? 'Pass' : 'Fail'}</span>`;
      const fails = r && r.failed && r.failed.length ? `<div class="fails">Failed: ${esc(r.failed.join('; '))}</div>` : '';
      return `<tr><td><b>${c.id}</b><div class="note" style="margin:0">${esc(c.type)}</div></td><td class="req">${esc(c.request)}${fails}${r && r.trace ? ` <button class="linkbtn" data-trace="${r.trace}" style="margin-left:0">Open trace</button>` : ''}</td>
        <td>${esc(c.expect_route)}</td><td>${esc(r ? r.route || '–' : '–')}</td><td>${r && r.total ? `${r.passed}/${r.total}` : '–'}</td><td>${r && r.ms ? fmtMs(r.ms) : '–'}</td><td>${res}</td></tr>`;
    }).join('');
    $('#evbody').innerHTML = rows;
    const done = EVAL_CASES.map(c => S.evalResults[c.id]).filter(r => r && !r.running);
    if (done.length) {
      const pass = done.filter(r => r.pass).length, ms = done.reduce((a, r) => a + (r.ms || 0), 0), tok = done.reduce((a, r) => a + (r.tokens || 0), 0);
      const cost = done.reduce((a, r) => a + (r.cost || 0), 0);
      $('#evsum').className = 'pill ' + (pass === done.length ? 'g' : 'a');
      $('#evsum').textContent = `${pass}/${done.length} passed · ${fmtMs(ms)} total · ~${tok.toLocaleString()} tokens · est. ${fmtCost(cost)}`;
    } else { $('#evsum').className = 'pill'; $('#evsum').textContent = 'Not run yet'; }
  }
  $('#evbody').addEventListener('click', (e) => { const b = e.target.closest('[data-trace]'); if (b) openTrace(b.dataset.trace); });
  $('#evstop').addEventListener('click', () => { S.evalStop = true; S.ctl && S.ctl.abort(); });
  $('#evrun').addEventListener('click', async () => {
    if (S.busy) { toast('Wait for the current request to finish.'); return; }
    if (!S.sample) { toast('Claude isn’t available in this view.'); return; }
    S.busy = true; S.evalStop = false; $('#evrun').disabled = true; $('#evstop').hidden = false; $('#send').disabled = true;
    S.evalResults = {}; renderEval();
    for (const c of EVAL_CASES) {
      if (S.evalStop) break;
      S.evalResults[c.id] = { running: true }; renderEval();
      S.ctl = new AbortController();
      const tr = await runMira(c.request, { sample: S.sample, files: S.files, cfg: cfg(), tier: S.settings.tier, signal: S.ctl.signal, source: 'eval ' + c.id, onStep: addTrace });
      addTrace(tr);
      const sc = scoreCase(c, tr.route, tr.output);
      S.evalResults[c.id] = { route: tr.route, passed: sc.passed, total: sc.total, pass: tr.status === 'ok' && sc.pass, failed: sc.checks.filter(x => !x.pass).map(x => x.check),
        ms: tr.total_ms, tokens: (tr.in_tokens || 0) + (tr.out_tokens || 0), cost: costOf(tr), trace: tr.id, error: tr.status !== 'ok' ? tr.error : null, output: tr.output };
      if (tr.status !== 'ok') S.evalResults[c.id].failed.unshift(errCopy(tr.error));
      renderEval(); store.set('eval', S.evalResults);
      if (tr.error === 'not_granted') break;
    }
    S.busy = false; S.ctl = null; $('#evrun').disabled = false; $('#evstop').hidden = true; $('#send').disabled = false;
    toast(S.evalStop ? 'Evaluation stopped' : 'Evaluation finished');
  });

  // ---------- data ----------
  const FILEDEFS = [['description', 'project_description.txt', 'Scope, goals and approach', '.txt,text/plain'], ['timeline', 'project_timeline.csv', 'Phases, weeks, milestones', '.csv,text/csv'],
    ['risks', 'project_risks.csv', 'Risk register', '.csv,text/csv'], ['tasks', 'sample_task_board.csv', 'Task board export', '.csv,text/csv']];
  function rowsOf(t) { return String(t || '').trim().split(/\r?\n/).length - 1; }
  function renderFiles() {
    const custom = store.get('files', {});
    $('#files').innerHTML = FILEDEFS.map(([k, name, desc, accept]) => `<div class="file"><h3>${name}</h3><p>${desc} · ${k === 'description' ? (S.files[k] || '').split(/\s+/).length + ' words' : rowsOf(S.files[k]) + ' rows'} · ${custom[k] ? 'your upload' : 'sample data'}</p>
      <label class="btn small">Replace file<input type="file" accept="${accept}" data-k="${k}"></label> ${custom[k] ? `<button class="btn small" data-reset="${k}">Use sample</button>` : ''}</div>`).join('');
  }
  $('#files').addEventListener('change', async (e) => {
    const inp = e.target.closest('input[type=file]'); if (!inp || !inp.files[0]) return;
    const text = await inp.files[0].text();
    const prev = S.files[inp.dataset.k];
    S.files[inp.dataset.k] = text;
    try { ground(S.files, cfg()); } catch (err) { S.files[inp.dataset.k] = prev; toast('That file doesn’t match the expected columns. Kept the previous file.'); renderFiles(); return; }
    const custom = store.get('files', {}); custom[inp.dataset.k] = text; store.set('files', custom);
    regrounding(); toast('File loaded; facts recomputed');
  });
  $('#files').addEventListener('click', (e) => {
    const b = e.target.closest('[data-reset]'); if (!b) return;
    const custom = store.get('files', {}); delete custom[b.dataset.reset]; store.set('files', custom);
    S.files[b.dataset.reset] = SEED.files[b.dataset.reset]; regrounding(); toast('Sample file restored');
  });
  function bindSettings() {
    const map = { 's-asof': 'AS_OF_DATE', 's-start': 'PROJECT_START', 's-tier': 'tier', 's-pin': 'price_in', 's-pout': 'price_out' };
    Object.entries(map).forEach(([id, k]) => {
      const el = $('#' + id); el.value = S.settings[k];
      el.addEventListener('change', () => {
        const v = el.type === 'number' ? Math.max(0, Number(el.value) || 0) : el.value;
        if ((k === 'AS_OF_DATE' || k === 'PROJECT_START') && !/^\d{4}-\d{2}-\d{2}$/.test(v)) { el.value = S.settings[k]; return; }
        S.settings[k] = v; store.set('settings', S.settings);
        if (k === 'AS_OF_DATE' || k === 'PROJECT_START') regrounding();
        renderTraceList(); renderEval();
      });
    });
  }
  function renderFacts() {
    const f = facts; if (!f) { $('#facts').innerHTML = '<p class="fails">The project files couldn’t be parsed.</p>'; return; }
    const li = (a) => a.length ? a.map(t => `<li><b>${esc(t.task_id)}</b> ${esc(t.task_name)} (${esc(t.status)}, due ${esc(t.due_date)}, ${esc(t.assignee)})</li>`).join('') : '<li>None</li>';
    $('#facts').innerHTML = `<h2>Grounded facts the agents receive</h2><p class="note" style="margin-top:0">Computed in code from the files above. Agents restate these; they never recalculate them.</p>
      <div class="kv"><div><small>Done</small><span>${f.task_counts['Done']}</span></div><div><small>In progress</small><span>${f.task_counts['In Progress']}</span></div><div><small>Blocked</small><span>${f.task_counts['Blocked']}</span></div><div><small>To do</small><span>${f.task_counts['To Do']}</span></div><div><small>Health</small><span>${esc(f.health.rag)}</span></div><div><small>Current phase</small><span style="font-size:14px">${esc(f.current_phase ? f.current_phase.phase_name : '–')}</span></div></div>
      <div class="md" style="padding:0"><h3>Blocked</h3><ul>${li(f.blocked)}</ul><h3>Overdue</h3><ul>${li(f.overdue)}</ul><h3>Due in the next 7 days</h3><ul>${li(f.due_within_7d)}</ul>
      <h3>Top risks by live evidence</h3><ol>${f.risks.slice(0, 3).map(r => `<li><b>${esc(r.risk_id)}</b> ${esc(r.category)}: score ${r.evidence_score} (${esc(r.evidence.map(e => e.task_id).join(', ') || 'no open task signal')})</li>`).join('')}</ol>
      <h3>Health reasons</h3><ul>${f.health.reasons.map(r => `<li>${esc(r)}</li>`).join('') || '<li>None</li>'}</ul></div>`;
  }

  // ---------- downloads ----------
  const csv = (rows) => rows.map(r => r.map(v => { const s = String(v ?? ''); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }).join(',')).join('\n');
  $$('.dl').forEach(b => b.addEventListener('click', async () => {
    if (!S.downloads) { toast('Downloads aren’t available in this view.'); return; }
    let filename, data;
    if (b.dataset.dl === 'traces-json') { filename = 'mira_traces.json'; data = JSON.stringify(S.traces, null, 2); }
    else if (b.dataset.dl === 'traces-csv') {
      filename = 'mira_traces.csv';
      data = csv([['trace_id', 'time', 'source', 'request', 'route', 'agent', 'status', 'latency_ms', 'claude_calls', 'est_input_tokens', 'est_output_tokens', 'est_cost_usd', 'steps'],
        ...S.traces.map(t => [t.id, t.at, t.source, t.request, t.route, t.agent, t.status, t.total_ms, t.llm_calls, t.in_tokens, t.out_tokens, costOf(t).toFixed(5), t.steps.map(s => `${s.name}:${s.ms}ms`).join(' | ')])]);
    } else {
      filename = 'mira_baseline_results.csv';
      data = csv([['test_id', 'type', 'request', 'expected_route', 'actual_route', 'checks_passed', 'checks_total', 'result', 'failed_checks', 'latency_ms', 'est_tokens', 'est_cost_usd', 'trace_id', 'output'],
        ...EVAL_CASES.map(c => { const r = S.evalResults[c.id] || {}; return [c.id, c.type, c.request, c.expect_route, r.route, r.passed, r.total, r.running ? 'RUNNING' : r.total ? (r.pass ? 'PASS' : 'FAIL') : '', (r.failed || []).join('; '), r.ms, r.tokens, r.cost != null ? r.cost.toFixed(5) : '', r.trace, r.output]; })]);
    }
    try { const res = await S.downloads.save({ filename, data }); if (res && res.status === 'saved') toast('Saved ' + filename); }
    catch (e) { if (e && e.code !== 'cancelled') toast('Couldn’t save the file (' + (e.code || 'error') + ').'); }
  }));

  // ---------- boot ----------
  showTab(); regrounding(); bindSettings(); renderTraceList(); renderEval();
  if (window.claude && window.claude.use) {
    claude.use('sample').then(s => { S.sample = s; if (!s) $('#nosample').hidden = false; });
    claude.use('downloads').then(d => { S.downloads = d; if (!d) $$('.dl').forEach(b => { b.hidden = true; }); });
  } else { $('#nosample').hidden = false; $$('.dl').forEach(b => { b.hidden = true; }); }
})();
