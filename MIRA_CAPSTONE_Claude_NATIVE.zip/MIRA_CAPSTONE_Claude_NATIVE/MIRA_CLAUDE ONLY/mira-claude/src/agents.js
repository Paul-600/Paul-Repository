// ===== Orchestrator (classifier prompt) =====
function classifierPrompt(request) {
  return `You are the ORCHESTRATOR of Mira, an AI project-intelligence assistant for PMs/TPMs at Nexora.
Mira is onboarded to ONE loaded project: "AI Adoption Project at ABCDE Ltd." (description, 8-phase timeline, risk register, 25-task board).
Your only job is to CLASSIFY the user's request. Do not answer it. Reply with ONLY a JSON object, no prose, no code fences.

Schema:
{"intent":"plan|risk|status|tracker|stakeholder|other","mode":"full|top_n|weekly|summary|blocked_at_risk|milestones|alerts|email","top_n":number|null,"sprint":number|null,"audience":"leadership|engineering|client|general","data_source":"loaded_project|user_inline|none","inline_content":string|null,"details_present":{"scope":bool,"goals":bool,"timeline":bool,"team":bool,"deliverables":bool},"window_days":number|null}

Intent guide:
- plan: create a project plan (mode "full").
- risk: risk assessment/matrix (mode "full") or "top N risks" (mode "top_n", set top_n).
- status: weekly status report (mode "weekly", set sprint if named) or a count summary of done/in progress/to do/blocked (mode "summary").
- tracker: blocked/overdue/at-risk tasks (mode "blocked_at_risk"), upcoming milestones (mode "milestones", set window_days), or a combined weekly alert (mode "alerts").
- stakeholder: stakeholder/executive/client update or email (mode "email", set sprint, audience; default "leadership").
- other: anything else.

data_source:
- "loaded_project" if the user refers to ABCDE, the provided project, task board, risk data, timeline, a sprint, "the project" or "current project".
- "user_inline" if the user supplies their OWN project text (often after "for:" or in quotes). Put that text in inline_content.
- "none" if there is no project information at all.
details_present: judge ONLY inline_content (all false if none). A duration alone counts as timeline only.

Examples:
"Generate a project plan for: \\"We want to build a website.\\"" -> {"intent":"plan","mode":"full","top_n":null,"sprint":null,"audience":"general","data_source":"user_inline","inline_content":"We want to build a website.","details_present":{"scope":false,"goals":false,"timeline":false,"team":false,"deliverables":false},"window_days":null}
"Give me the top 5 risks from the risk register" -> {"intent":"risk","mode":"top_n","top_n":5,"sprint":null,"audience":"general","data_source":"loaded_project","inline_content":null,"details_present":{"scope":false,"goals":false,"timeline":false,"team":false,"deliverables":false},"window_days":null}

Request to classify:
${request}`;
}

// ===== Keyword fallback, used when the classifier gives no usable JSON =====
function keywordIntent(req) {
  if (/stakeholder|email|executive update|client update/i.test(req)) return { intent: 'stakeholder', mode: 'email' };
  if (/blocked|at risk of missing|overdue|deadline/i.test(req)) return { intent: 'tracker', mode: 'blocked_at_risk' };
  if (/milestone/i.test(req)) return { intent: 'tracker', mode: 'milestones' };
  if (/\brisks?\b/i.test(req)) return { intent: 'risk', mode: /top\s*\d/i.test(req) ? 'top_n' : 'full' };
  if (/how many|summar|count/i.test(req)) return { intent: 'status', mode: 'summary' };
  if (/status|report|progress/i.test(req)) return { intent: 'status', mode: 'weekly' };
  if (/\bplan\b/i.test(req)) return { intent: 'plan', mode: 'full' };
  return { intent: 'other', mode: 'full' };
}

// ===== Orchestrator guardrails (deterministic) =====
function decide(request, c, facts) {
  c = c || {};
  const req = request || '';
  const dp = Object.assign({ scope: false, goals: false, timeline: false, team: false, deliverables: false }, c.details_present || {});
  const kw = keywordIntent(req);
  let intent = c.intent || kw.intent;
  let mode = c.mode || kw.mode;
  const overrides = [];
  if (!c.intent) overrides.push(`intent from keywords: ${kw.intent}`);
  let data_source = c.data_source || 'none';
  const inlineMatch = req.match(/\bfor\s*:\s*["'\u201c\u2018](.+?)["'\u201d\u2019]?\s*(\(|$)/i);
  const mentionsProject = /abcde|provided (project|data|description|file)|task ?board|risk (data|csv|register)|timeline|sprint\s*\d|\bthe project\b|current project/i.test(req);
  const saysNoDetails = /\bno (other |further |more )?(details|information|info|context)\b|without (any )?details/i.test(req);
  if (saysNoDetails && !/abcde/i.test(req)) {
    if (data_source !== 'none') overrides.push('data_source -> none ("no details" phrasing)');
    data_source = 'none';
    Object.keys(dp).forEach(k => { dp[k] = false; });
    dp.timeline = /\d+\s*-?\s*(day|week|month)/i.test(req);
  } else if (inlineMatch && !/abcde/i.test(req)) {
    if (data_source !== 'user_inline') overrides.push('data_source -> user_inline (quoted inline text)');
    data_source = 'user_inline'; c.inline_content = c.inline_content || inlineMatch[1];
  } else if (mentionsProject) {
    if (data_source !== 'loaded_project') overrides.push('data_source -> loaded_project (project keywords)');
    data_source = 'loaded_project';
  }
  if (/deadline alert|milestone alert|weekly alert/i.test(req)) { intent = 'tracker'; mode = 'alerts'; }
  const sprintMatch = req.match(/sprint\s*(\d+)/i);
  const sprint = sprintMatch ? Number(sprintMatch[1]) : (c.sprint ?? null);
  const topMatch = req.match(/top\s*(\d+)/i);
  const top_n = topMatch ? Number(topMatch[1]) : (c.top_n ?? null);
  if (intent === 'risk' && top_n) mode = 'top_n';
  const inline = String(c.inline_content || '').trim();
  const words = inline ? inline.split(/\s+/).length : 0;
  const present = Object.entries(dp).filter(([, v]) => v).map(([k]) => k);
  const missing = Object.entries(dp).filter(([, v]) => !v).map(([k]) => k);
  let route = intent, clarify_kind = null;
  if (intent === 'plan') {
    if (data_source !== 'loaded_project' && (present.length < 3 || words < 20)) { route = 'clarify'; clarify_kind = 'plan'; }
  } else if (intent === 'risk') {
    if (data_source !== 'loaded_project' && (!(dp.scope || dp.goals) || words < 15)) { route = 'clarify'; clarify_kind = 'risk'; }
  } else if (['status', 'tracker', 'stakeholder'].includes(intent)) {
    if (data_source === 'user_inline') { route = 'clarify'; clarify_kind = 'no_task_data'; }
  } else { route = 'clarify'; clarify_kind = 'unsupported'; }
  return { intent, mode, route, clarify_kind, data_source, sprint, top_n: top_n || 3,
    audience: c.audience || 'leadership', window_days: c.window_days || facts.milestone_window_days,
    inline_content: inline || null, details_present: dp, missing_details: missing, overrides };
}

// ===== Shared grounding rules =====
const RULES = `GROUNDING RULES (non-negotiable):
1. Use ONLY facts in the CONTEXT JSON. Never add tasks, milestones, risks, goals, KPIs, dates, people, percentages or budgets that are not in CONTEXT.
2. Copy task IDs, task names, risk IDs, phase and milestone names exactly as written in CONTEXT.
3. If something the format asks for is not in CONTEXT, write "Not specified in source data" instead of estimating.
4. Counts, dates, health (RAG), priorities and rankings are pre-computed in CONTEXT. Restate them; never recalculate or change them.
5. Output clean GitHub-flavoured Markdown using exactly the section structure given. No preamble, no closing chit-chat, no code fences around the whole answer.
6. End with one line: "_Sources: <source_files>. Data as of <as_of_date>._"`;
const pack = (agent, system, request, context) => ({ agent, prompt: `${system}\n\nREQUEST: ${request}\n\nCONTEXT:\n${JSON.stringify(context)}` });
const RANK_RULE = 'Blocked task = 3, overdue = 2, due within 7 days = 1.5 (in progress) or 1 (to do), due within 30 days = 0.5; summed over open tasks linked to the risk.';

function plannerAgent(request, f, dec) {
  if (dec.data_source === 'loaded_project') {
    return pack('planner', `You are the PLANNER AGENT of Mira. Produce a structured project plan for the loaded project.
${RULES}
7. Objectives must come from project_description only (quote the stated targets). Do not add new goals.

FORMAT:
# Project Plan: AI Adoption Project, ABCDE Ltd.
## 1. Overview  (2-3 sentences from project_description)
## 2. Objectives and Success Targets  (bullets, only what the description states)
## 3. Scope  (business functions in scope, as stated)
## 4. Phased Plan  (table: Phase | Weeks | Dates | Key Activities | Milestones / Deliverables | Current Status)
## 5. Milestone Schedule  (table: Milestone | Due Date | Status / Risk)
## 6. Team and Governance  (task-force description, then team_from_task_board: assignee, workstreams, open tasks)
## 7. Dependencies and Schedule Observations  (from milestone_issues and schedule_observations)
## 8. Assumptions and Open Questions  (things a plan needs that the sources do not give, e.g. budget)`, request,
    { as_of_date: f.as_of_date, project_start: f.project_start, current_week: f.current_week, current_phase: f.current_phase,
      project_description: f.project_description, timeline: f.timeline, team_from_task_board: f.team_from_task_board,
      schedule_observations: f.schedule_observations, source_files: ['project_description.txt', 'project_timeline.csv', 'sample_task_board.csv'] });
  }
  return pack('planner', `You are the PLANNER AGENT of Mira. Build a DRAFT plan using ONLY the user's own description in CONTEXT.user_description.
${RULES}
7. Label every duration, phase or role you propose as "(proposed - confirm)". List what is still missing under Open Questions.
FORMAT: # Draft Project Plan / ## Overview / ## Objectives / ## Phases (table) / ## Milestones / ## Team / ## Open Questions`, request,
    { as_of_date: f.as_of_date, user_description: dec.inline_content, source_files: ['user request'] });
}

function riskAgent(request, f, dec) {
  const extra = `7. Only risks in CONTEXT may appear. Never create a new risk or risk ID.
8. "Live evidence" must cite only task IDs listed in that risk's evidence array; if the array is empty write "No open task signal".
9. evidence_priority and rank are Mira's evidence-based ranking from the task board (rule in CONTEXT.ranking_rule). Say so once.`;
  if (dec.data_source !== 'loaded_project') {
    return pack('risk_assessor', `You are the RISK ASSESSOR AGENT of Mira. Assess risks using ONLY the user's description in CONTEXT.user_description.
${RULES}
7. Only list risks that follow directly from details the user gave; for each, quote the detail it comes from. Then list the information still needed.
FORMAT: # Draft Risk Assessment / ## Risk Matrix (table: # | Category | Risk | Based on | Impact | Mitigation) / ## Information Needed`, request,
      { as_of_date: f.as_of_date, user_description: dec.inline_content, source_files: ['user request'] });
  }
  if (dec.mode === 'top_n') {
    const n = Math.min(Number(dec.top_n) || 3, f.risks.length);
    return pack('risk_assessor', `You are the RISK ASSESSOR AGENT of Mira. Report the top ${n} risks for the loaded project.
${RULES}
${extra}
FORMAT:
# Top ${n} Risks: AI Adoption Project, ABCDE Ltd.
One sentence explaining the ranking rule.
Then for each risk in rank order:
## <rank>. <risk_id> - <category>
- **Risk:** ...
- **Impact:** ...
- **Live evidence:** ...
- **Mitigation (from register):** ...
- **Suggested next step:** one action tied to the evidence task
## Other risks to watch  (one line listing the remaining risk IDs and categories)`, request,
      { as_of_date: f.as_of_date, ranking_rule: RANK_RULE, top_risks: f.risks.slice(0, n),
        other_risks: f.risks.slice(n).map(r => ({ risk_id: r.risk_id, category: r.category })), source_files: ['project_risks.csv', 'sample_task_board.csv'] });
  }
  return pack('risk_assessor', `You are the RISK ASSESSOR AGENT of Mira. Produce the categorized risk matrix for the loaded project (logistics + AI adoption).
${RULES}
${extra}
FORMAT:
# Risk Assessment: AI Adoption Project, ABCDE Ltd.
## Summary  (2-3 sentences: how many risks, how many High/Medium/Low by evidence_priority, the top 3 by rank)
## Risk Matrix  (table, in rank order: Rank | ID | Category | Risk | Impact | Evidence Priority | Live Evidence (task IDs) | Mitigation)
## Logistics-Specific Exposure  (map risks to the in-scope functions named in project_description: demand forecasting, route optimization, inventory management, customer support; only where the link is explicit)
## Recommended Actions This Week  (max 5, each tied to an evidence task ID)`, request,
    { as_of_date: f.as_of_date, project_description: f.project_description, ranking_rule: RANK_RULE, risks: f.risks,
      source_files: ['project_risks.csv', 'project_description.txt', 'sample_task_board.csv'] });
}

function statusAgent(request, f, dec) {
  const row = (t) => ({ task_id: t.task_id, task_name: t.task_name, status: t.status, assignee: t.assignee, priority: t.priority, sprint: t.sprint, due_date: t.due_date, due_in_days: t.due_in_days, is_overdue: t.is_overdue, description: t.description });
  const byStatus = (list) => ({ 'Done': list.filter(t => t.status === 'Done').map(t => t.task_id), 'In Progress': list.filter(t => t.status === 'In Progress').map(t => t.task_id),
    'Blocked': list.filter(t => t.status === 'Blocked').map(t => t.task_id), 'To Do': list.filter(t => t.status === 'To Do').map(t => t.task_id) });
  if (dec.mode === 'summary') {
    return pack('status_reporter', `You are the STATUS REPORTER AGENT of Mira. Give a short project status summary.
${RULES}
FORMAT:
# Project Status Summary: AI Adoption Project, ABCDE Ltd.
**As of:** <as_of_date> (Week <current_week>, <current phase>)   **Overall health:** <RAG>
## Task Counts  (table: Status | Count | Task IDs, rows Done, In Progress, Blocked, To Do, Total; use task_counts exactly)
## Highlights  (max 4 bullets: blocked, overdue, next milestone)`, request,
      { as_of_date: f.as_of_date, current_week: f.current_week, current_phase: f.current_phase, task_counts: f.task_counts,
        task_ids_by_status: byStatus(f.tasks), health: f.health, blocked: f.blocked, overdue: f.overdue,
        upcoming_milestones: f.upcoming_milestones, source_files: ['sample_task_board.csv', 'project_timeline.csv'] });
  }
  const sprint = dec.sprint || f.current_sprint;
  const sprintTasks = f.tasks.filter(t => t.sprint_num === sprint).map(row);
  return pack('status_reporter', `You are the STATUS REPORTER AGENT of Mira. Write the weekly status report for Sprint ${sprint}.
${RULES}
7. If sprint_tasks is empty, say "No task data found for Sprint ${sprint} in sample_task_board.csv" and stop.
FORMAT:
# Weekly Status Report: Sprint ${sprint}
**Project:** AI Adoption Project, ABCDE Ltd.   **Week of:** <as_of_date> (Week <current_week>, <current phase>)   **Overall health:** <RAG>
> Health reasons: <health.reasons as one line>
## 1. Sprint ${sprint} at a Glance  (table: Status | Count, computed from sprint_status_ids only)
## 2. Completed  (Sprint ${sprint} Done tasks; if none say so, then list recently_completed_previous_sprint)
## 3. In Progress  (table: ID | Task | Owner | Due | Note)
## 4. To Do  (table: ID | Task | Owner | Priority | Due)
## 5. Blocked and Overdue  (all blocked tasks project-wide + carry_over_open overdue tasks; ID, task, owner, reason from description, days)
## 6. Upcoming Milestones (next ${f.milestone_window_days} days) and Missed Milestones
## 7. Decisions / Help Needed  (only items that follow from blocked or overdue tasks)
## 8. Project-wide Counts  (one line from task_counts)`, request,
    { as_of_date: f.as_of_date, current_week: f.current_week, current_phase: f.current_phase, sprint,
      sprint_tasks: sprintTasks, sprint_status_ids: byStatus(sprintTasks),
      recently_completed_previous_sprint: f.tasks.filter(t => t.sprint_num === sprint - 1 && t.status === 'Done').map(row),
      carry_over_open: f.tasks.filter(t => t.sprint_num < sprint && t.status !== 'Done').map(row),
      blocked: f.blocked, overdue: f.overdue, upcoming_milestones: f.upcoming_milestones, missed_milestones: f.missed_milestones,
      health: f.health, task_counts: f.task_counts, source_files: ['sample_task_board.csv', 'project_timeline.csv'] });
}

function trackerAgent(request, f, dec) {
  const win = Number(dec.window_days) || f.milestone_window_days;
  const DAY = 86400000, asOf = Date.parse(f.as_of_date + 'T00:00:00Z');
  const endOf = (p) => Date.parse(p.end_date + 'T00:00:00Z');
  const inWindow = f.timeline.filter(p => endOf(p) >= asOf && endOf(p) <= asOf + win * DAY)
    .map(p => ({ phase: p.phase, phase_name: p.phase_name, due_date: p.end_date, days_away: p.days_until_phase_end, milestones: p.milestones, milestone_risk: p.milestone_risk, issues: p.milestone_issues }));
  const sections = {
    blocked_at_risk: `## 1. Blocked Tasks  (table: ID | Task | Owner | Priority | Due | Days to due | Blocker reason from description | Suggested action)
## 2. Overdue Tasks  (table: ID | Task | Owner | Due | Days overdue | Status | Suggested action)
## 3. Due in the Next 7 Days - At Risk if Not Done  (table: ID | Task | Owner | Status | Due | Risk note)
## 4. Milestones Affected  (phases whose milestone_risk is At risk or Missed, with the issues listed)`,
    milestones: `## 1. Milestones Due in the Next ${win} Days  (table: Phase | Milestone / Deliverable | Due Date | Days Away | Risk | Why)
If none, write "No milestones fall due between <as_of_date> and the end of the window" and name next_milestone_after_window.
## 2. Recently Missed Milestones  (from missed_milestones)
## 3. Suggested Actions  (max 4, each tied to a task ID from the issues)`,
  };
  sections.alerts = sections.blocked_at_risk + '\n' + sections.milestones.replace(/## (\d)/g, (m, n) => `## ${Number(n) + 4}`);
  const mode = sections[dec.mode] ? dec.mode : 'blocked_at_risk';
  const title = mode === 'milestones' ? 'Upcoming Milestones' : mode === 'alerts' ? 'Mira Weekly Alert' : 'Blocked and At-Risk Tasks';
  return pack('milestone_tracker', `You are the MILESTONE & DEADLINE TRACKER AGENT of Mira. Compare the timeline against task progress and flag risk early.
${RULES}
7. Suggested actions must be concrete (owner + action) and only about tasks/milestones in CONTEXT.
FORMAT:
# ${title}: AI Adoption Project, ABCDE Ltd.
**As of:** <as_of_date> (Week <current_week>)
${sections[mode]}`, request,
    { as_of_date: f.as_of_date, current_week: f.current_week, current_phase: f.current_phase, window_days: win,
      blocked: f.blocked, overdue: f.overdue, due_within_7d: f.due_within_7d, milestones_in_window: inWindow, missed_milestones: f.missed_milestones,
      next_milestone_after_window: f.timeline.find(p => endOf(p) > asOf + win * DAY) || null,
      at_risk_phases: f.timeline.filter(p => ['At risk', 'Missed'].includes(p.milestone_risk)).map(p => ({ phase: p.phase, phase_name: p.phase_name, end_date: p.end_date, milestone_risk: p.milestone_risk, issues: p.milestone_issues })),
      source_files: ['sample_task_board.csv', 'project_timeline.csv'] });
}

function stakeholderAgent(request, f, dec) {
  const sprint = dec.sprint || f.current_sprint;
  const tasks = f.tasks.filter(t => t.sprint_num === sprint).map(t => ({ task_id: t.task_id, task_name: t.task_name, status: t.status, assignee: t.assignee, priority: t.priority, due_date: t.due_date, is_overdue: t.is_overdue, description: t.description }));
  const phases = [...new Set(f.tasks.filter(t => t.sprint_num === sprint).map(t => t.phase))];
  const counts = { Done: 0, 'In Progress': 0, Blocked: 0, 'To Do': 0 };
  tasks.forEach(t => { counts[t.status] = (counts[t.status] || 0) + 1; });
  const tone = { leadership: 'executive: outcome-first, 150-250 words, no technical detail', engineering: 'engineering: specific, task-level, owners and dates',
    client: 'client-facing: confident, professional, no internal blame', general: 'executive: outcome-first, 150-250 words' }[dec.audience] || 'executive';
  return pack('stakeholder_comms', `You are the STAKEHOLDER COMMS AGENT of Mira. Write a stakeholder update email for Sprint ${sprint}. Audience: ${tone}.
${RULES}
7. Mention ONLY tasks in CONTEXT.sprint_tasks. Do not mention any other sprint's tasks. For "next steps" use only open Sprint ${sprint} tasks and the phase milestones in CONTEXT.phases.
8. Replace rule 6 with a sign-off "Best regards, [Your name], Project Manager, Nexora" and nothing after it.
9. If sprint_tasks is empty, say no task data exists for Sprint ${sprint}.
FORMAT:
**Subject:** AI Adoption Project (ABCDE Ltd.) - Sprint ${sprint} Update
Greeting line
**Summary:** 2-3 sentences (progress count from sprint_counts, sentiment justified by the data)
**Completed this sprint:** bullets
**In progress:** bullets with owner and due date (flag overdue ones plainly)
**Risks / support needed:** only from overdue or blocked Sprint ${sprint} tasks; else "None this sprint"
**Next steps:** bullets
Sign-off`, request,
    { as_of_date: f.as_of_date, sprint, sprint_counts: counts, sprint_tasks: tasks,
      phases: f.timeline.filter(p => phases.includes(p.phase)).map(p => ({ phase: p.phase, phase_name: p.phase_name, start_date: p.start_date, end_date: p.end_date, milestones: p.milestones, milestone_risk: p.milestone_risk })),
      source_files: ['sample_task_board.csv', 'project_timeline.csv'] });
}

// ===== Clarification agent (rules, no LLM) =====
function clarifyAgent(dec) {
  return typo(clarifyText(dec));
}
const typo = (t) => t.replace(/(\w)'(\w)/g, '$1\u2019$2').replace(/"([^"\n]+)"/g, '\u201c$1\u201d');
function clarifyText(dec) {
  const ask = { scope: 'Scope: what is in and out (features, systems, users, channels)?', goals: 'Goals: what outcomes or measurable targets define success?',
    timeline: 'Timeline: start date, end date or duration, and any fixed deadlines?', team: 'Team: team size, roles, and who the sponsor or decision-maker is?',
    deliverables: 'Deliverables: what concrete outputs must be handed over?' };
  const given = dec.inline_content ? `You provided: "${String(dec.inline_content).replace(/[.!?\s]+$/, '')}".` : 'No project details were provided.';
  if (dec.clarify_kind === 'plan') {
    const order = ['scope', 'goals', 'deliverables', 'timeline', 'team'];
    const need = order.filter(k => dec.missing_details.includes(k));
    const have = order.filter(k => !dec.missing_details.includes(k));
    const list = (need.length ? need : order).map((k, i) => `${i + 1}. ${ask[k]}`).join('\n');
    return `## More detail needed before I can build a plan\n\n${given} That is not enough to create a reliable project plan, and I won't invent phases, milestones or dates.\n\n${have.length ? `Already clear: ${have.join(', ')}.\n\n` : ''}Please share:\n${list}\n\nOnce I have these, I'll generate phases, milestones, deliverables and a timeline. If you meant the loaded ABCDE Ltd. AI Adoption Project, say "plan for the ABCDE project".`;
  }
  if (dec.clarify_kind === 'risk') {
    return `## Insufficient detail for a risk assessment\n\n${given} I can't assess project-specific risks without knowing what the project is, so I won't list generic or invented risks.\n\nPlease share:\n1. What the project is and its objectives\n2. Scope: systems, data and business functions involved\n3. Timeline and key milestones\n4. Team, vendors and budget constraints\n5. Known constraints (regulatory, legacy systems, data sensitivity)\n\nOr ask for "the risk assessment for the ABCDE Ltd. project" to use the loaded risk register.`;
  }
  if (dec.clarify_kind === 'no_task_data') {
    return `## No task data available\n\n${given} This is a statement, not task data, so I can't produce a status report from it. I won't estimate progress, percentages or task statuses.\n\nTo generate a report, either:\n1. Load a task board CSV (task, status, owner, sprint and due date) in the Data tab, or\n2. Ask for a report on the loaded project, e.g. "weekly status report for Sprint 3 from the task board".`;
  }
  return `## Here's what I can help with\n\n- **Project plan**: "Generate a project plan for the ABCDE project"\n- **Risk assessment**: "Risk assessment" or "top 3 risks"\n- **Weekly status report**: "Status report for Sprint 3"\n- **Status summary**: "How many tasks are done, in progress, to do?"\n- **Blocked and at-risk tasks**, and **upcoming milestones**\n- **Stakeholder update email**: "Stakeholder email for Sprint 2"\n\nRephrase your request as one of these and I'll route it to the right agent.`;
}

const AGENTS = {
  plan: { fn: plannerAgent, name: 'Planner', key: 'planner' },
  risk: { fn: riskAgent, name: 'Risk Assessor', key: 'risk_assessor' },
  status: { fn: statusAgent, name: 'Status Reporter', key: 'status_reporter' },
  tracker: { fn: trackerAgent, name: 'Milestone Tracker', key: 'milestone_tracker' },
  stakeholder: { fn: stakeholderAgent, name: 'Stakeholder Comms', key: 'stakeholder_comms' },
  clarify: { fn: null, name: 'Clarification', key: 'clarification' },
};

// ===== Baseline eval cases (T1-T12) =====
const EVAL_CASES = [
 { id: 'T1', type: 'Plan (detailed)', request: 'Generate a project plan for the AI Adoption Project at ABCDE Ltd. Use the provided project description.', expect_route: 'plan',
   must_include: ['Project Initiation', 'Monitoring & Review', 'Project charter signed off', '15%', '10%'], must_not_regex: ['\\b(20|25|30|40|50)%'] },
 { id: 'T2', type: 'Plan (vague)', request: 'Generate a project plan for: "We want to build a chatbot."', expect_route: 'clarify', must_include: ['scope', 'timeline', 'team'], must_not_regex: ['Phase 1', 'Week 1'] },
 { id: 'T3', type: 'Risk (detailed)', request: 'Generate a risk assessment for the AI Adoption Project at ABCDE Ltd. Use the provided project description.', expect_route: 'risk',
   must_include: ['R01', 'R05', 'R09', 'R10', 'Data Quality', 'Integration'], must_not_regex: ['\\bR1[1-9]\\b'] },
 { id: 'T4', type: 'Risk (vague)', request: 'Generate a risk assessment for: "New project starting soon."', expect_route: 'clarify', must_include: ['project'], must_not_regex: ['\\bR0\\d\\b', 'Vendor Lock-in', 'Model Performance Drift'] },
 { id: 'T5', type: 'Status (data)', request: 'Generate a weekly status report using the sample task board data for Sprint 3.', expect_route: 'status',
   must_include: ['Shortlist AI use cases', 'Define success criteria for each use case', 'Vendor evaluation for ML platform', 'Legal review of data usage', 'T024'], must_not_regex: ['\\bT0(2[6-9]|[3-9]\\d)\\b'] },
 { id: 'T6', type: 'Status (no data)', request: 'Generate a weekly status report for: "Things are going fine." (no task data)', expect_route: 'clarify', must_include: ['No task data'], must_not_regex: ['\\d+\\s?%'] },
 { id: 'T7', type: 'Risk analysis', request: 'What are the top 3 risks for the ABCDE Ltd project based on the risk data?', expect_route: 'risk', must_include: ['R09', 'R01', 'R05'], must_not_regex: ['\\bR1[1-9]\\b'] },
 { id: 'T8', type: 'Tracking', request: 'Which tasks are blocked or at risk of missing their deadline based on the task board?', expect_route: 'tracker', must_include: ['T024', 'Security review', 'T006'], must_not_regex: ['\\bT0(2[6-9]|[3-9]\\d)\\b'] },
 { id: 'T9', type: 'Plan (edge)', request: 'Generate a project plan for a 2-week project with no details provided.', expect_route: 'clarify', must_include: ['scope', 'goals', 'deliverables'], must_not_regex: ['Day 1', 'Phase 1'] },
 { id: 'T10', type: 'Status summary', request: 'Summarize the current project status: how many tasks are done, in progress, and to do?', expect_route: 'status', must_include: [],
   must_regex: ['Done\\s*\\|\\s*5\\b', 'In Progress\\s*\\|\\s*3\\b', 'Blocked\\s*\\|\\s*1\\b', 'To Do\\s*\\|\\s*16\\b'] },
 { id: 'T11', type: 'Timeline', request: 'What milestones are coming up in the next 2 weeks based on the timeline?', expect_route: 'tracker', must_include: ['Final list of prioritized use cases'], must_not_regex: ['Pilot results report', 'Full production rollout'] },
 { id: 'T12', type: 'Comms', request: 'Generate a stakeholder update email summarizing Sprint 2 progress.', expect_route: 'stakeholder',
   must_include: ['Subject', 'Audit existing data infrastructure', 'Map current logistics workflows', 'Identify data gaps'],
   must_not_regex: ['T00[789]', 'T02[45]', 'Shortlist AI use cases', 'Vendor evaluation', 'Legal review', 'Security review'] },
];

function scoreCase(c, route, output) {
  const out = String(output || '');
  const checks = [{ check: `routed to ${c.expect_route}`, pass: route === c.expect_route }];
  (c.must_include || []).forEach(s => checks.push({ check: `includes "${s}"`, pass: out.toLowerCase().includes(s.toLowerCase()) }));
  (c.must_regex || []).forEach(s => checks.push({ check: `matches /${s}/`, pass: new RegExp(s, 'i').test(out) }));
  (c.must_not_regex || []).forEach(s => checks.push({ check: `does not match /${s}/`, pass: !new RegExp(s, 'i').test(out) }));
  const passed = checks.filter(x => x.pass).length;
  return { checks, passed, total: checks.length, pass: passed === checks.length };
}
