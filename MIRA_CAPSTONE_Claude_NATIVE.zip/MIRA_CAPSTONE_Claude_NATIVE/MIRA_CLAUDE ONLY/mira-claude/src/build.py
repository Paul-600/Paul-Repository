# Rebuilds ../mira_app.html from the source files and ../data. Run: python3 src/build.py
import json, pathlib
here = pathlib.Path(__file__).resolve().parent; root = here.parent; D = root / 'data'
files = {'description': (D/'project_description.txt').read_text(), 'timeline': (D/'project_timeline.csv').read_text(),
         'risks': (D/'project_risks.csv').read_text(), 'tasks': (D/'sample_task_board.csv').read_text()}
seed = json.dumps({'files': files}).replace('</', '<\\/')
core = '\n'.join((here/f).read_text() for f in ['ground.js', 'agents.js', 'pipeline.js'])
html = (here/'ui.html').read_text().replace('__SEED__', seed).replace('__CORE__', core).replace('__APP__', (here/'app.js').read_text())
(root/'mira_app.html').write_text(html); print('wrote mira_app.html', len(html), 'bytes')
