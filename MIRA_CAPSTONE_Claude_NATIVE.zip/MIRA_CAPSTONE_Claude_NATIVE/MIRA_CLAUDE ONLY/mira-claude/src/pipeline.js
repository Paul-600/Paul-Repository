// ===== Mira pipeline: grounding -> orchestrator -> guardrails -> agent -> finalize =====
const estTokens = (s) => Math.ceil(String(s || '').length / 4);
const newId = () => 'tr_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

async function runMira(request, opts) {
  const { sample, files, cfg, tier, onStep, onText, signal, source } = opts;
  const now = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());
  const trace = { id: newId(), at: new Date().toISOString(), source: source || 'chat', request, steps: [], route: null, agent: null, output: '', status: 'running', model: null };
  const t0 = now();
  const step = async (name, kind, fn, detail) => {
    const s = { name, kind, status: 'running', started: Math.round(now() - t0), ms: 0, in_tokens: 0, out_tokens: 0, detail: detail || '' };
    trace.steps.push(s); onStep && onStep(trace);
    const a = now();
    try {
      const r = await fn(s);
      s.status = 'ok'; s.ms = Math.round(now() - a); onStep && onStep(trace); return r;
    } catch (e) {
      s.status = 'error'; s.ms = Math.round(now() - a); s.error = e && (e.code || e.message) || String(e); onStep && onStep(trace); throw e;
    }
  };
  try {
    const facts = await step('Grounding layer', 'code', async (s) => {
      const f = ground(files, cfg);
      s.detail = `Parsed ${f.tasks.length} tasks, ${f.timeline.length} phases, ${f.risks.length} risks. Health ${f.health.rag}.`;
      return f;
    });
    const cls = await step('Orchestrator agent', 'llm', async (s) => {
      const p = classifierPrompt(request);
      s.in_tokens = estTokens(p);
      let c = {};
      try { c = await sample.json(p, { modelTier: 'quick', signal }); }
      catch (e) { if (e && (e.code === 'cancelled' || e.code === 'not_granted' || e.code === 'rate_limited')) throw e; s.detail = 'Classifier returned unreadable JSON; guardrails decide from rules.'; c = {}; }
      s.out_tokens = estTokens(JSON.stringify(c));
      if (!s.detail) s.detail = `intent=${c.intent || '?'} mode=${c.mode || '?'} data_source=${c.data_source || '?'}`;
      s.output = c;
      return c;
    });
    const dec = await step('Guardrails', 'rule', async (s) => {
      const d = decide(request, cls, facts);
      s.detail = `route=${d.route}${d.clarify_kind ? ` (${d.clarify_kind})` : ''}${d.sprint ? `, sprint ${d.sprint}` : ''}${d.overrides.length ? `; overrides: ${d.overrides.join('; ')}` : ''}`;
      s.output = d;
      return d;
    });
    trace.route = dec.route; trace.mode = dec.mode; trace.decision = dec;
    const agent = AGENTS[dec.route] || AGENTS.clarify;
    trace.agent = agent.name;
    if (!agent.fn) {
      trace.output = await step(`${agent.name} agent`, 'rule', async (s) => { const o = clarifyAgent(dec); s.out_tokens = 0; s.detail = 'Rule-based response, no Claude call.'; onText && onText(o); return o; });
    } else {
      const built = agent.fn(request, facts, dec);
      trace.prompt = built.prompt;
      trace.output = await step(`${agent.name} agent`, 'llm', async (s) => {
        s.in_tokens = estTokens(built.prompt);
        const r = await sample(built.prompt, { modelTier: tier || 'default', signal, onText: ({ text }) => { onText && onText(text); } });
        s.out_tokens = estTokens(r.text);
        s.detail = (r.truncated ? 'Answer was cut short. ' : '') + (r.modelApplied ? `model ${r.modelApplied}` : `tier ${tier || 'default'}`);
        trace.model = r.modelApplied || null;
        return r.text;
      }, '');
    }
    await step('Finalize', 'code', async (s) => { s.detail = `Total est. tokens ${trace.steps.reduce((a, x) => a + x.in_tokens + x.out_tokens, 0)}`; });
    trace.status = 'ok';
  } catch (e) {
    trace.status = e && e.code === 'cancelled' ? 'cancelled' : 'error';
    trace.error = e && (e.code || e.message) || String(e);
    if (!trace.output) trace.output = e && e.text ? e.text : '';
  }
  trace.total_ms = Math.round(now() - t0);
  trace.in_tokens = trace.steps.reduce((a, x) => a + x.in_tokens, 0);
  trace.out_tokens = trace.steps.reduce((a, x) => a + x.out_tokens, 0);
  trace.llm_calls = trace.steps.filter(x => x.kind === 'llm').length;
  onStep && onStep(trace);
  return trace;
}
